<html>
<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
<body>


<form align="center" action="<?=$_SERVER['PHP_SELF']?>"> IP: <input type="text" name="id" align="center">
<input type="submit" align="center" value="Check">
</form>
</body>

<?php

$filename = './GeoLite2-Country.mmdb';
if (file_exists($filename)) {
    echo "Файл базы IP в последний раз был изменён: " . date("F d Y H:i:s.", filectime($filename));
}
print "<br><br>";
$today = date('y-m-d');
print "Сегодня: ";
echo $today;
echo "\n";
echo "<br>";
if (isset($_GET['id']))
{
$id = $_GET['id'];
}
else 
{
exit;
}
print "IP: ";
print $id;
print "\n";

require_once 'vendor/autoload.php';
use GeoIp2\Database\Reader;
$reader = new Reader('./GeoLite2-Country.mmdb');
$record = $reader->country($id);
echo "<br>";
print "Код cтраны: ";
print($record->country->isoCode . "\n");
echo "<br>";
print "Страна: ";
print($record->country->names['ru'] . "\n");
echo "<br>";
print "IP Pool: ";
print($record->traits->network . "\n");
echo "<br>";
?>

</html>
